Program Space requirements
=======

The **Minimal** configuration requires 866 bytes.

The **DTL** configuration requires 2072 bytes.

The **Nominal** configuration requires 2800 bytes.  TinyGPS uses about 2400 bytes.  TinyGPS++ uses about 2700 bytes.

The **Full** configuration requires 3462 bytes.

(All configuration numbers include 166 bytes PROGMEM.)

